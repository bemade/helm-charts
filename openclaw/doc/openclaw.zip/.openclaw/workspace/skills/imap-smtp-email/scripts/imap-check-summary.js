#!/usr/bin/env node

/**
 * Lightweight IMAP check - outputs only summary info (no full body/HTML)
 * For use in cron jobs where token efficiency matters
 */

const Imap = require('imap');
const { simpleParser } = require('mailparser');
const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

const DEFAULT_MAILBOX = process.env.IMAP_MAILBOX || 'INBOX';

function createImapConfig() {
  return {
    user: process.env.IMAP_USER,
    password: process.env.IMAP_PASS,
    host: process.env.IMAP_HOST || '127.0.0.1',
    port: parseInt(process.env.IMAP_PORT) || 1143,
    tls: process.env.IMAP_TLS === 'true',
    tlsOptions: {
      rejectUnauthorized: process.env.IMAP_REJECT_UNAUTHORIZED !== 'false',
    },
    connTimeout: 10000,
    authTimeout: 10000,
  };
}

async function connect() {
  const config = createImapConfig();
  if (!config.user || !config.password) {
    throw new Error('Missing IMAP_USER or IMAP_PASS');
  }
  return new Promise((resolve, reject) => {
    const imap = new Imap(config);
    imap.once('ready', () => resolve(imap));
    imap.once('error', (err) => reject(new Error(`IMAP connection failed: ${err.message}`)));
    imap.connect();
  });
}

async function checkSummary(limit = 5) {
  const imap = await connect();
  try {
    await new Promise((resolve, reject) => {
      imap.openBox(DEFAULT_MAILBOX, true, (err, box) => {
        if (err) reject(err);
        else resolve(box);
      });
    });

    const searchCriteria = ['UNSEEN'];
    const fetchOptions = {
      bodies: ['HEADER.FIELDS (FROM TO SUBJECT DATE)'],
      markSeen: false,
    };

    return new Promise((resolve, reject) => {
      imap.search(searchCriteria, (err, results) => {
        if (err) { reject(err); return; }
        if (!results || results.length === 0) { resolve([]); imap.end(); return; }

        const fetch = imap.fetch(results.slice(0, limit), fetchOptions);
        const messages = [];
        let done = false;

        fetch.on('message', (msg) => {
          let headerText = '';
          let attrs = null;
          
          msg.on('body', (stream) => {
            stream.on('data', (chunk) => { headerText += chunk.toString('utf8'); });
          });
          
          msg.once('attributes', (a) => { attrs = a; });
          
          msg.once('end', () => {
            if (attrs) {
              messages.push({
                uid: attrs.uid,
                from: extractHeader(headerText, 'From'),
                to: extractHeader(headerText, 'To'),
                subject: extractHeader(headerText, 'Subject'),
                date: attrs.date ? new Date(attrs.date).toISOString() : null,
              });
            }
          });
        });

        fetch.once('error', (e) => { done = true; reject(e); });
        fetch.once('end', () => {
          if (!done) {
            done = true;
            resolve(messages);
          }
        });
      });
    });
  } finally {
    imap.end();
  }
}

function extractHeader(headerText, fieldName) {
  const regex = new RegExp(`${fieldName}:\\s*(.+?)(?:\\r?\\n|$)`, 'i');
  const match = headerText.match(regex);
  return match ? match[1].trim() : '';
}

// Main
async function main() {
  const args = process.argv.slice(2);
  const limit = parseInt(args.find(a => a.startsWith('--limit='))?.split('=')[1] || '5');
  
  try {
    const emails = await checkSummary(limit);
    console.log(JSON.stringify(emails, null, 2));
    process.exit(0);
  } catch (err) {
    console.error('Error:', err.message);
    process.exit(1);
  }
}

// Timeout wrapper
const timeout = setTimeout(() => {
  console.error('Timeout after 10s');
  process.exit(1);
}, 10000);

main().then(() => clearTimeout(timeout));
