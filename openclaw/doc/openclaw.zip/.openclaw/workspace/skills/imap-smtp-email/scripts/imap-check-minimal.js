#!/usr/bin/env node

/**
 * Ultra-lightweight IMAP check - outputs plain text summary only
 * Format: "N unread: sender1 (subject1), sender2 (subject2)..."
 */

const Imap = require('imap');
const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

const DEFAULT_MAILBOX = process.env.IMAP_MAILBOX || 'INBOX';

function createImapConfig() {
  return {
    user: process.env.IMAP_USER,
    password: process.env.IMAP_PASS,
    host: process.env.IMAP_HOST || '127.0.0.1',
    port: parseInt(process.env.IMAP_PORT) || 1143,
    tls: process.env.IMAP_TLS === 'true',
    tlsOptions: { rejectUnauthorized: process.env.IMAP_REJECT_UNAUTHORIZED !== 'false' },
    connTimeout: 5000,
    authTimeout: 5000,
  };
}

async function connect() {
  const config = createImapConfig();
  if (!config.user || !config.password) throw new Error('Missing IMAP credentials');
  return new Promise((resolve, reject) => {
    const imap = new Imap(config);
    imap.once('ready', () => resolve(imap));
    imap.once('error', (err) => reject(new Error(`IMAP error: ${err.message}`)));
    imap.connect();
  });
}

async function checkMinimal(limit = 3) {
  const imap = await connect();
  try {
    await new Promise((resolve, reject) => {
      imap.openBox(DEFAULT_MAILBOX, true, (err) => err ? reject(err) : resolve());
    });
    
    const emails = await new Promise((resolve, reject) => {
      imap.search(['UNSEEN'], (err, uids) => {
        if (err) { reject(err); return; }
        if (!uids || uids.length === 0) { resolve([]); imap.end(); return; }
        
        const fetch = imap.fetch(uids.slice(0, limit), {
          bodies: ['HEADER.FIELDS (FROM SUBJECT)'],
          markSeen: false,
        });
        
        const results = [];
        fetch.on('message', (msg) => {
          let headers = '';
          msg.on('body', (stream) => {
            stream.on('data', (chunk) => { headers += chunk.toString('utf8'); });
          });
          msg.once('attributes', (attrs) => {
            const from = headers.match(/From:\s*(.+?)(?:\r?\n|$)/i)?.[1]?.trim() || '';
            const subject = headers.match(/Subject:\s*(.+?)(?:\r?\n|$)/i)?.[1]?.trim() || '';
            results.push({ from, subject, date: attrs.date });
          });
        });
        fetch.once('end', () => { results.sort((a, b) => new Date(b.date) - new Date(a.date)); resolve(results); });
        fetch.once('error', reject);
      });
    });
    
    if (emails.length === 0) {
      console.log('No unread emails.');
      return;
    }
    
    // Output minimal text
    console.log(`${emails.length} unread:`);
    emails.forEach(e => {
      const cleanFrom = e.from.replace(/["<>]/g, '').split('@')[0];
      console.log(`  - ${cleanFrom}: ${e.subject}`);
    });
  } finally {
    imap.end();
  }
}

checkMinimal().catch(err => { console.error('Error:', err.message); process.exit(1); });
