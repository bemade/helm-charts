1. When writing commit messages, do not include any co-authored by AI mention.

# Odoo Module Development

## Project Structure

- Check `.env` in the project root for the Odoo version. Odoo core is in `odoo/`,
  enterprise in `enterprise/`.
- Non-client-specific modules go in the appropriate submodule under `.repos/` with a
  relative symlink from `addons/<module_name>` (relative paths so CI doesn't break).
- Client-specific modules go directly in `addons/`.
- When editing modules that live in `.repos/`, use the `addons/<module_name>` path so
  the IDE linter resolves imports correctly.

## Module Development Process

1. Scaffold the module folder.
2. Propose the module name to the user and wait for confirmation before creating it.
3. Define the module's purpose in the manifest `description` in RST format (or
   `readme/DESCRIPTION.md` for OCA contributions).
4. Wait for the user to confirm the manifest is correct before proceeding.
5. Write separate test files for each use case with acceptance criteria at the top — don't
   write the test implementations yet.
6. Once use cases are agreed upon, do TDD: write a failing test, check it fails, write
   code, check it passes. Repeat.

## Odoo Coding Conventions

- Starting in Odoo 17, there are no `attrs` attributes in view XML.
- In Odoo 19.0, use `models.Constraint` rather than `_sql_constraints`.
- Use `Command` (from `odoo.fields`) to set x2many field values in write dicts.
- License: **LGPL-3**.
- Author: **Bemade Inc.** (Marc Durepos <marc@bemade.org>, https://www.bemade.org, github: mdurepos).

## Testing

- Use test-driven development unless testing is truly unfeasible (e.g. unreplicable
  external service too complex to mock). At minimum write unit tests if integration
  tests aren't possible.
- Run tests with: `2>&1 | tee /tmp/test.log` to save output for analysis.
- Use `--test-tags` to run only relevant tests during development.
- Use `odoo.tests.Form` and related proxies to simulate user interaction — catches
  missing view fields, onchange issues, etc.
- When a test expects an exception, use `mute_logger` from `odoo.tools.misc` to
  suppress error logs that would be false alarms.
- Pay attention to the linter. It's usually right.

## Odoo MCP Tools

- When calling `message_post` via the Odoo MCP tool, always pass
  `"body_is_html": true` in params when the body contains HTML markup.

### Odoo Model Registry (MANDATORY for model/field/method questions)

**BLOCKING REQUIREMENT:** When working in an Odoo project (16–19) and you need
to understand models, fields, method override chains, or inheritance, you MUST
use the `odoo-model-registry` MCP tools **before** falling back to grep.
They are deferred tools — load them first with ToolSearch:

```
ToolSearch(query: "+odoo-model-registry model")
```

Then call the appropriate tool with `project_path` set to the project root:

- `mcp__odoo-model-registry__model_info` — full model metadata: fields, inheritance, extending modules
- `mcp__odoo-model-registry__field_info` — single field: type, compute, depends, module overrides
- `mcp__odoo-model-registry__method_overrides` — MRO override chain with file:line locations
- `mcp__odoo-model-registry__model_graph` — inheritance graph: parents, children, mixins
- `mcp__odoo-model-registry__search_models` — find models by name or description

These return structured data in milliseconds. Use grep only for view XML,
controllers, JS, or reading actual source (registry gives file:line, then Read).

**Note:** The first call for a project takes ~3-6s (registry load). Subsequent
calls are instant (~1-15ms). Workers auto-shutdown after 10 minutes of inactivity.

### Code Context Gathering

When you need to understand how something works in the codebase — tracing
models, fields, methods, inheritance chains, call chains, or doing orientation
surveys — **delegate to the `context-gatherer` agent** rather than doing Search
calls yourself. It has access to the Odoo model registry MCP tools and
optimized search patterns for multiple ecosystems. Use it for any question that
requires tracing code across multiple files or modules.

## Git & CI

- Never commit or push unless explicitly instructed.
- Before pushing, determine if tests can be run first.
- Run `odoo-dev test` (or equivalent) to run all module tests before pushing.
