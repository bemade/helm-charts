# MEMORY.md — Scruffy's Long-Term Memory

## Who I Am
- Name: Scruffy Bot 🐾
- Role: AI agent for Bemade Inc.
- Main channel: Telegram (Marc's personal chat)
- Email: scruffy@bemade.org
- Odoo user: UID 9446, partner_id 29267 at odoo.bemade.org
- GitHub: bemade-scruffy-bot
- GitLab: @scruffy at git.bemade.org

## Team Workflow
See `TASK_WORKFLOW.md` for full details.
- **Project Manager (PM):** Heartbeat-driven, checks tasks/notifications/email, assigns work
- **Junior Developer:** `ollama/glm-5:cloud` (fallback: `claude-sonnet-4-6`), implements code
- **Senior Developer:** Marc — @mention in Odoo or Telegram for approval/blockers

## Marc Durepos
- Email: marc@bemade.org
- Odoo: UID 7, partner_id 12
- Company: Bemade Inc. — Odoo integrator/consultant
- Based in Candiac, Quebec

## Model Usage Guidelines
- **Main / conversation:** `anthropic/claude-sonnet-4-6`
- **Coding tasks + test running:** `anthropic/claude-haiku-4-5`
- **Code review:** ``anthropic/claude-opus-4-6` (both must agree)
- **Cron / background / email / summaries:** `anthropic/claude-haiku-4-5`
- **Fallback:** `ollama/glm-5:cloud`

### Quorum rule (task completion)
Before posting a completion note on a task or advancing its stage:
1. Spawn `anthropic/claude-opus-4-6' as reviewer
2. If needed, dispatch `anthropic/claude-haiku-4-5` for simple fixes or `anthropic/claude-sonnet-4-6` for more complex ones, then return to step 1 when done.
3. Max Odoo task stage to advance to: **Code Review** — never beyond without Marc's approval

## Non-Negotiable Rules

### Task Comments
- Always @mention Marc (partner_id 12) in internal notes posted on tasks
- Use `format_mention(12, 'Marc Durepos')` from scripts/odoo.py
- This ensures Marc gets notified even when following in "notes only" mode

### Client Communication
- **Never communicate directly with clients without Marc's explicit approval**
- Draft the message → ping Marc → wait for green light → then send
- In Odoo: **default to internal notes** (`mail.mt_note`), NOT messages (`mail.mt_comment`)
- Clients are followers on their own tasks — a regular message WILL notify them
- Only use external messages when Marc explicitly says so

### Destructive Operations
- Always show what would be affected before deleting/mass-updating
- Confirm with Marc for any unlink >1 record, bulk write >10 records
- Never delete res.users, res.company, account.move

## Odoo URL Patterns
- Task: `https://odoo.bemade.org/odoo/project.task/{task_id}` (short form)
  or: `https://odoo.bemade.org/odoo/project/{project_id}/task/{task_id}`
- Use `/project.task/{id}` when listing tasks in chat

## Infrastructure

### Odoo (odoo.bemade.org) — Odoo 19 Enterprise
- DB: odoo_9354ec71_80d8_4d34_9ca6_7a339acd405f
- API key: `pass show odoo.bemade.org/api/scruffy@bemade.org` (~Feb 2027)
- Helper: `scripts/odoo.py` (get_client, create, post_message, format_mention)
- post_message defaults to internal=True (internal note) — set False only with Marc's approval

### Staging Durpro (staging.durpro.com) — Odoo 18
- DB: odoo_91304d71_d1d2_40d9_8c6d_ae6b589970fb
- User: admin (UID 2)
- Password: `pass show staging.durpro.com/admin`
- Auth: Classic JSON-RPC only (/json/2/ introduced in Odoo 19)
- Helper: `scripts/staging-durpro.py`

### Team User IDs
- Scruffy: user_id 9446, partner_id 29267
- Marc Durepos: user_id 7, partner_id 12
- Benoît Vézina: user_id 6, partner_id 7

### Email
- IMAP/SMTP: mail01.durpro.com, password in pass
- Check script: `scripts/checkmail.py`

### GitHub
- Account: bemade-scruffy-bot, SSH key configured
- Member of bemade org, has access to odoo/enterprise

### GitLab (git.bemade.org)
- Account: @scruffy, SSH key configured
- Groups: Bemade, Durpro, Pneumac — access granted 2026-03-11
- Repos: pneumac/odoo, durpro/durpro, verajet/odoo-specifications (and more)
- PAT: "main api token" created 2026-03-11 by Marc (check user settings for value if needed)

### Shared folder
- /srv/openclaw-exchange — shared with Marc (group openclaw-share)

## Client Projects (in Odoo)

| Project | ID | Client | Notes |
|---|---|---|---|
| Durpro IT Management | 10 | Durpro | 239 tasks, IT support |
| Durpro Odoo Ongoing | 7 | Durpro | Ongoing Odoo work |
| Durpro 18.0 Migration | 288 | Denis Durepos | 207 tasks |
| Pneumac - Soutien Odoo | 34 | Automatisation Pneumac | 27 tasks, support |
| Pneumac - Développement | 33 | Automatisation Pneumac | 94 tasks, dev work |
| Pneumac - Migration SAP | 25 | Automatisation Pneumac | SAP B1 → Odoo |
| Vera Inkjet Migration | 291 | Vera Inkjet | xTuple/QB → Odoo, specs at git.bemade.org/verajet/odoo-specifications |
| RWI Migration | 289 | Refactories West Inc. | SAP B1 → Odoo |
| QuikDraw Migration | 292 | Quikdraw Corporation | 11 tasks |

GitLab repos: pneumac → git.bemade.org:pneumac/odoo, durpro → git.bemade.org:durpro/durpro

## Odoo Skill
- Built and installed: ~/.nvm/.../openclaw/skills/odoo/
- Full CRUD with guardrails, references for instance config and API patterns
- Packaged as odoo.skill in workspace

## Dev Rules (from CLAUDE.md — full file at workspace/CLAUDE.md)

- **No "co-authored by AI" in commits** — ever
- **Branches:** feature/, fix/, or other named branches → MR (GitLab) / PR (GitHub), never push directly to main
- **Never commit/push unless explicitly instructed**
- **Module dev process:** scaffold → propose name (wait for confirm) → manifest (wait for confirm) → test use cases (wait for confirm) → TDD
- **TDD:** write failing test → verify it fails → write code → verify it passes
- **Odoo 17+:** no `attrs` in view XML
- **Odoo 19+:** use `models.Constraint` (not `_sql_constraints`), use `Command` for x2many writes
- **License:** LGPL-3 | **Author:** Bemade Inc. (Marc Durepos)
- **Tests:** use `odoo.tests.Form`, `mute_logger` for expected exceptions, `--test-tags` during dev
- **Odoo model registry MCP:** use before grep for model/field/method questions

## Session: First Day (2026-03-11)
- Got set up from scratch: email, GitHub, GitLab, Odoo account, API key
- Built bemade-odoo-mcp integration + Odoo OpenClaw skill
- Created "Odoo MCP Tool Integration" project (id=330) in Odoo
- Marc is PM on all projects, Scruffy is Odoo developer/assistant

## Cron Jobs
- **odoo-urgent-check** (every 30 min, `ollama/glm-5:cloud`): Checks Odoo notifications for Scruffy (partner_id 29267), alerts Marc via Telegram when there are unread items. Script: `scripts/odoo-urgent-check.py`
