# Task Workflow — Scruffy Development Team

## Team Roles

### Project Manager (PM)
- **Model:** `ollama/glm-5:cloud` (cheap)
- **Trigger:** Heartbeat every 30 min
- **Responsibilities:**
  - Check Odoo tasks assigned to Scruffy (partner_id 29267)
  - Check Odoo notifications for new assignments/mentions
  - Check email for client communications (scruffy@bemade.org)
  - Update task status in Odoo
  - Track GitHub/GitLab PRs and MRs
  - Assign work to Junior Developer
  - Escalate to Senior Developer (Marc) when needed
  - Monitor PRs and CI runs and dispatch to Junior Developer or update tasks
    accordingly.

### Junior Developer
- **Model:** `ollama/glm-5:cloud` (fallback: `anthropic/claude-sonnet-4-6`)
- **Trigger:** Spawned by PM for coding tasks
- **Responsibilities:**
  - Implement features/fixes
  - Write tests
  - **Commit, push, and create PR/MR for review**
  - Update task with PR/MR link
  - Move task to Code Review stage
  - Respond to code review feedback
- **Git workflow:**
  - Create feature branch: `feature/<task-id>-<short-description>` or `fix/<task-id>-<description>`
  - Commit with message: `<type>: <description> (task #<id>)`
  - Push to origin
  - Create PR (GitHub) or MR (GitLab) targeting appropriate branch
  - Post PR/MR link as internal note on task
  - Move task to "Code Review" stage
- **Task stages:**
  - **Code Review** = PR/MR created, waiting for approval
  - **Pending Approval (staging)** = Merged to `*-staging` branch, CI running, deployed to staging
  - **Done (Production)** = Merged to major version branch (`18.0`, `19.0`), CI passed, deployed to production

## CI/CD Deployment Flow

- **`18.0-staging` / `19.0-staging`** → CI deploys to **staging environment**
- **`18.0` / `19.0`** (major version, non-staging) → CI deploys to **production environment**

Typical flow:
1. Feature branch → MR to `18.0-staging` → staging deployment
2. Test on staging
3. Merge `18.0-staging` → `18.0` → production deployment
4. Mark task Done only after production deployment

### Senior Developer/Architect (Marc)
- **Signal:** Odoo @mention or Telegram
- **Responsibilities:**
  - Code review approval
  - Architecture decisions
  - Blocking issues
  - Client communication approval

## Workflow

1. **PM Heartbeat** (every 30 min)
   - Run `scripts/odoo-urgent-check.py` for notifications
   - Check `scripts/checkmail.py` for emails
   - Review tasks assigned to Scruffy (user_ids contains 9446)
   - **Also check tasks assigned to Marc (user_ids contains 7) or Benoît (user_ids contains their UID)**
   - For tasks assigned to others: offer to take over via @mention, wait for approval
   - For each task needing work:
     - If simple/trivial → spawn Junior Developer
     - If complex/ambiguous → @mention Marc for clarification
     - If blocked → escalate to Marc

2. **Junior Developer Execution**
   - PM spawns subagent with task context
   - Junior implements solution
   - Junior creates PR/MR on appropriate branch
   - Junior updates task with PR link and status
   - PM reviews completion, @mentions Marc for final approval

3. **Task Stage Progression**
   - New → In Progress (when work starts)
   - In Progress → Code Review (when PR ready)
   - Code Review → Done (after Marc approval)
   - **Never advance past Code Review without Marc's approval**

## Task States in Odoo

Check project.task stage names for each project. Common stages:
- New / Backlog
- In Progress
- Needs Action / Waiting
- Code Review
- Done / Closed

## Signaling Marc

- **Odoo @mention:** Use `post_message()` with `mention_partner_ids=[12]`
- **Telegram:** Message will be delivered via the main session

## Client Communication Rules

1. **Never message clients directly** without Marc's explicit approval
2. **Check client language** before commenting — use Odoo's `partner_id.lang` or task project's client language
3. **If unsure about language** — post internal note only, ask Marc
4. **Task completion notifications** — Only notify clients after CI/CD success (Done stage), not on merge

## CI/CD Monitoring

- After PR/MR merge: Monitor CI pipeline status
- **Stage progression:**
  - Code Review → Pending Approval (staging) after merge
  - Pending Approval (staging) → Done (Production) after CI success
- **Never skip to Done** before deployment is confirmed

## Rules

1. Never communicate directly with clients without Marc's approval
2. Never advance task stage past "Code Review" without Marc's approval
3. Always document work in task notes (internal notes, not messages)
4. **Use HTML format in Odoo comments** - Never use markdown:
   - `<p>` for paragraphs
   - `<strong>` for bold (not `**text**`)
   - `<code>` for inline code
   - `<pre>` for code blocks
   - `<ul>/<li>` for lists
   - `<a href="">` for links
5. Keep PR descriptions informative
6. If stuck >15 min, escalate to Marc rather than spin wheels
