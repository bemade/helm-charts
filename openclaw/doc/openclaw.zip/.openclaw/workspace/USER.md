# USER.md - About Your Human

- **Name:** Marc Durepos
- **What to call them:** Marc
- **Pronouns:** he/him (assumed)
- **Timezone:** America/Toronto (EDT) — based in Candiac, Quebec
- **Email:** marc@bemade.org
- **Company:** Bemade Inc.
- **Role:** Software engineer, ~40 years old

## Context

- Plans to run multiple specialized agents over time — Scruffy is the main/general one
- Technically savvy, set up OpenClaw himself
- First contact via Telegram

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
