#!/usr/bin/env python3
"""
odoo-discuss-check.py - Check Odoo Discuss channels for new messages to Scruffy.

Run as a heartbeat check, outputs JSON for the agent to interpret.
Tracks seen message IDs per channel in memory/heartbeat-state.json.

Usage:
    python3 scripts/odoo-discuss-check.py [--json]
"""

import sys
import os
import json
import asyncio
import subprocess
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, '/home/openclaw/.local/share/uv/tools/bemade-odoo-mcp/lib/python3.12/site-packages')
sys.path.insert(0, '/home/openclaw/.openclaw/workspace')

from odoo_mcp.client import OdooClient  # noqa: E402

# Paths
WORKSPACE = Path('/home/openclaw/.openclaw/workspace')
STATE_FILE = WORKSPACE / 'memory' / 'heartbeat-state.json'

# Odoo config
ODOO_URL = "https://odoo.bemade.org"
ODOO_DB = "odoo_9354ec71_80d8_4d34_9ca6_7a339acd405f"
SCRUFFY_PARTNER_ID = 29267  # Scruffy Bot partner ID


def get_api_key() -> str:
    result = subprocess.run(
        ["pass", "show", "odoo.bemade.org/api/scruffy@bemade.org"],
        capture_output=True, text=True, check=True
    )
    return result.stdout.splitlines()[0].strip()


def load_state() -> dict:
    """Load heartbeat state from disk."""
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text())
        except (json.JSONDecodeError, IOError):
            pass
    return {}


def save_state(state: dict) -> None:
    """Save heartbeat state to disk."""
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(json.dumps(state, indent=2))


def strip_html(html: str) -> str:
    """Simple HTML to plain text conversion."""
    import re
    # Remove HTML tags
    text = re.sub(r'<[^>]+>', '', html)
    # Decode common entities
    text = text.replace('&nbsp;', ' ')
    text = text.replace('&amp;', '&')
    text = text.replace('&lt;', '<')
    text = text.replace('&gt;', '>')
    text = text.replace('&quot;', '"')
    return text.strip()


async def check_discuss_channels():
    """Check for new messages in Scruffy's Discuss channels."""
    key = get_api_key()
    client = OdooClient(
        base_url=ODOO_URL,
        database=ODOO_DB,
        username="scruffy@bemade.org",
        api_key=key,
    )
    
    messages = []
    state = load_state()
    
    # Initialize discuss_seen if not present
    if 'discuss_seen' not in state:
        state['discuss_seen'] = {}
    
    try:
        # Get all channel memberships for Scruffy
        memberships = await client.search_read(
            'discuss.channel.member',
            domain=[('partner_id', '=', SCRUFFY_PARTNER_ID)],
            fields=[
                'channel_id',
                'message_unread_counter',
                'seen_message_id',
                'is_pinned',
            ],
            limit=50,
        )
        
        for member in memberships:
            channel_ref = member.get('channel_id')
            if not channel_ref:
                continue
            
            channel_id = channel_ref[0]
            channel_name = channel_ref[1] if len(channel_ref) > 1 else f'Channel {channel_id}'
            unread_count = member.get('message_unread_counter', 0)
            
            # Get recent messages in this channel
            recent_messages = await client.search_read(
                'mail.message',
                domain=[
                    ('model', '=', 'discuss.channel'),
                    ('res_id', '=', channel_id),
                ],
                fields=['author_id', 'body', 'create_date', 'subject'],
                limit=20,
                order='create_date DESC',
            )
            
            # Track seen message IDs per channel
            seen_key = str(channel_id)
            seen_ids = set(state['discuss_seen'].get(seen_key, []))
            
            # Find new messages (not yet seen)
            new_messages = []
            for msg in recent_messages:
                msg_id = msg['id']
                author_ref = msg.get('author_id', [None, 'Unknown'])
                author_name = author_ref[1] if isinstance(author_ref, list) and len(author_ref) > 1 else str(author_ref)
                author_id = author_ref[0] if isinstance(author_ref, list) else None
                
                # Skip messages from Scruffy itself
                if author_id == SCRUFFY_PARTNER_ID:
                    continue
                
                # Check if this is a new message
                if msg_id not in seen_ids:
                    body_html = msg.get('body', '')
                    body_text = strip_html(body_html)
                    
                    new_messages.append({
                        'message_id': msg_id,
                        'channel_id': channel_id,
                        'channel_name': channel_name,
                        'author': author_name,
                        'author_id': author_id,
                        'body_html': body_html[:500],  # Truncate
                        'body_text': body_text[:300] if body_text else '(empty or attachment)',
                        'timestamp': msg.get('create_date'),
                        'is_odobot': author_name == 'OdooBot',
                    })
            
            # Update seen state
            if recent_messages:
                all_ids = [m['id'] for m in recent_messages]
                state['discuss_seen'][seen_key] = all_ids
            
            # Add to results
            if new_messages:
                messages.extend(new_messages)
        
        # Save state
        save_state(state)
        
    except Exception as e:
        sys.stderr.write(f"Error checking Discuss channels: {e}\n")
        return [], str(e)
    finally:
        await client.close()
    
    return messages, None


def main():
    messages, error = asyncio.run(check_discuss_channels())
    
    # Sort by timestamp (oldest first for readability)
    messages.sort(key=lambda m: m.get('timestamp', ''))
    
    # Filter out OdooBot welcome messages (they're not actionable)
    actionable_messages = [
        m for m in messages
        if not (m.get('is_odobot') and 'Hello' in m.get('body_text', '') and 'discover' in m.get('body_text', '').lower())
    ]
    
    output = {
        'timestamp': datetime.now(timezone.utc).isoformat(),
        'has_new_messages': len(actionable_messages) > 0,
        'message_count': len(actionable_messages),
        'messages': actionable_messages,
    }
    
    if error:
        output['error'] = error
    
    print(json.dumps(output, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()