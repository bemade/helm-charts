#!/usr/bin/env python3
import asyncio
import sys
sys.path.insert(0, '/home/openclaw/.local/share/uv/tools/bemade-odoo-mcp/lib/python3.12/site-packages')
sys.path.insert(0, '/home/openclaw/.openclaw/workspace')
from scripts.odoo import get_client, post_message, format_mention

async def main():
    client = get_client()
    marc = format_mention(12, 'Marc Durepos')
    
    # Post internal note
    await post_message(client, 'project.task', 3312,
        body_html=f'''<p>{marc} Fixed portal confirmation issue.</p>
<p><strong>Issue 1: Loading stuck</strong> - Clients couldn't confirm quotes because <code>delivery_billing_mode</code> constraint blocked <code>action_confirm()</code>. Portal didn't handle the error gracefully.</p>
<p><strong>Fix:</strong></p>
<ul>
<li>Added <code>_can_be_confirmed_on_portal()</code> method to sale.order</li>
<li>Portal now hides accept/pay buttons when <code>delivery_billing_mode</code> is missing</li>
<li>Shows warning message (EN/FR): "This quotation cannot be confirmed because no delivery billing mode is selected"</li>
</ul>
<p><strong>Issue 2: No payment button</strong> - You mentioned you'll reactivate <code>portal_confirmation_pay</code> on the company.</p>
<p><strong>Commit:</strong> <code>273bd82</code> on <code>18.0-staging</code> branch</p>
<p>Ready for testing on Pneumac staging.</p>''',
        mention_partner_ids=[12])
    
    # Move to Code Review
    await client.write('project.task', ids=[3312], values={'stage_id': 261})
    await client.close()

asyncio.run(main())