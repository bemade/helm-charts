#!/usr/bin/env python3
"""
Investigate the Pneumac DBM (Delivery Billing Method) blocking issue - Part 2.
"""
import sys
import json
import urllib.request

URL = "https://staging.pneumac.qc.ca"
DB = "odoo_91aea74e_be15_4e57_a7bb_c47fd9727b99"
ADMIN_KEY = "551a54d37a6040d144d4830b037a340af4440122"

def rpc(service, method, args):
    payload = json.dumps({
        "jsonrpc": "2.0",
        "method": "call",
        "params": {"service": service, "method": method, "args": args}
    }).encode()
    req = urllib.request.Request(
        f"{URL}/jsonrpc",
        data=payload,
        headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        result = json.loads(resp.read())
    if "error" in result:
        raise RuntimeError(f"RPC error: {result['error']['data']['message']}\n{result['error']['data']['debug'][:500]}")
    return result["result"]

uid = rpc("common", "authenticate", [DB, "admin", ADMIN_KEY, {}])
print(f"✓ uid={uid}")

def call(model, method, args=None, kwargs=None):
    return rpc("object", "execute_kw", [DB, uid, ADMIN_KEY, model, method, args or [], kwargs or {}])

# 1. Check delivery_billing_mode field details
print("\n--- delivery_billing_mode field details ---")
fields = call("sale.order", "fields_get", [["delivery_billing_mode"]], {"attributes": ["string", "type", "required", "selection", "default"]})
print(json.dumps(fields, indent=2))

# 2. Get base.automation fields first
print("\n--- base.automation available fields ---")
aa_fields = call("base.automation", "fields_get", [], {"attributes": ["string", "type"]})
relevant = {k: v for k, v in aa_fields.items() if k in ["name", "trigger", "active", "model_id", "action_server_ids", "action_ids"]}
print(json.dumps(relevant, indent=2))

# 3. Get automated actions on sale.order with safe fields
print("\n--- Automated actions on sale.order ---")
auto_actions = call("base.automation", "search_read",
    [[["model_id.model", "=", "sale.order"]]],
    {"fields": ["name", "trigger", "active"], "limit": 50})
for a in auto_actions:
    print(f"  [{a['id']}] {a['name']} | trigger={a['trigger']} | active={a['active']}")

# 4. Server actions on sale.order
print("\n--- Server actions on sale.order ---")
sa_fields = call("ir.actions.server", "fields_get", [], {"attributes": ["string", "type"]})
safe_fields = [f for f in ["name", "code", "state", "model_id"] if f in sa_fields]
sa = call("ir.actions.server", "search_read",
    [[["model_id.model", "=", "sale.order"]]],
    {"fields": safe_fields, "limit": 50})
for s in sa:
    content = str(s).lower()
    if any(kw in content for kw in ["delivery", "billing", "dbm", "carrier", "prepaid", "method"]):
        print(f"  [{s['id']}] {s['name']} | state={s.get('state', '?')}")
        if s.get("code"):
            print(f"    CODE: {s['code'][:400]}")

# 5. Record rules on sale.order
print("\n--- Record rules on sale.order ---")
rules = call("ir.rule", "search_read",
    [[["model_id.model", "=", "sale.order"]]],
    {"fields": ["name", "domain_force", "active", "groups"], "limit": 20})
for r in rules:
    print(f"  [{r['id']}] {r['name']} | active={r['active']}")
    print(f"    domain: {r['domain_force']}")

# 6. Constraints on sale.order
print("\n--- SQL constraints on sale.order ---")
constraints = call("ir.model.constraint", "search_read",
    [[["model", "=", "sale.order"]]],
    {"fields": ["name", "type", "definition", "message"], "limit": 30})
for c in constraints:
    print(f"  [{c['id']}] {c['name']} | type={c['type']}")
    if c.get("definition"):
        print(f"    def: {c['definition']}")
    if c.get("message"):
        print(f"    msg: {c['message']}")

# 7. Look for modules with DBM-related names
print("\n--- Installed modules: sale-related ---")
mods = call("ir.module.module", "search_read",
    [[["state", "=", "installed"], ["name", "ilike", "sale"]]],
    {"fields": ["name", "summary"], "limit": 100})
for m in mods:
    name_lower = m['name'].lower()
    summ_lower = (m.get('summary') or '').lower()
    if any(kw in name_lower or kw in summ_lower for kw in ["delivery", "billing", "carrier", "portal", "prepaid", "transport"]):
        print(f"  {m['name']}: {m['summary']}")

# 8. Check sale_portal module / portal acceptance flow  
print("\n--- Checking portal-related modules ---")
portal_mods = call("ir.module.module", "search_read",
    [[["state", "=", "installed"], ["name", "ilike", "portal"]]],
    {"fields": ["name", "summary"], "limit": 30})
for m in portal_mods:
    print(f"  {m['name']}: {m['summary']}")

print("\n✓ Done")
