#!/usr/bin/env python3
"""
Investigate the Pneumac DBM (Delivery Billing Method) blocking issue.
Task 3312 - URGENT Stripe payment blocking on portal.
"""
import sys
import json
import urllib.request
import urllib.error

URL = "https://staging.pneumac.qc.ca"
DB = "odoo_91aea74e_be15_4e57_a7bb_c47fd9727b99"
ADMIN_KEY = "551a54d37a6040d144d4830b037a340af4440122"

def rpc(service, method, args):
    payload = json.dumps({
        "jsonrpc": "2.0",
        "method": "call",
        "params": {
            "service": service,
            "method": method,
            "args": args
        }
    }).encode()
    req = urllib.request.Request(
        f"{URL}/jsonrpc",
        data=payload,
        headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        result = json.loads(resp.read())
    if "error" in result:
        raise RuntimeError(f"RPC error: {result['error']}")
    return result["result"]

# Authenticate
uid = rpc("common", "authenticate", [DB, "admin", ADMIN_KEY, {}])
print(f"✓ Authenticated as uid={uid}")

def call(model, method, args=None, kwargs=None):
    return rpc("object", "execute_kw", [DB, uid, ADMIN_KEY, model, method, args or [], kwargs or {}])

# 1. Check if sale.order has delivery_billing_method_id field
print("\n--- Checking sale.order fields related to DBM ---")
so_fields = call("sale.order", "fields_get", [], {"attributes": ["string", "type", "required"]})
dbm_fields = {k: v for k, v in so_fields.items() if "delivery" in k.lower() or "billing_method" in k.lower() or "dbm" in k.lower()}
for fname, finfo in dbm_fields.items():
    print(f"  {fname}: {finfo}")

# 2. Look for automated actions related to DBM
print("\n--- Automated actions on sale.order ---")
auto_actions = call("base.automation", "search_read",
    [[["model_id.model", "=", "sale.order"]]],
    {"fields": ["name", "trigger", "active", "action_server_id"], "limit": 50})
for a in auto_actions:
    print(f"  [{a['id']}] {a['name']} | trigger={a['trigger']} | active={a['active']}")

# 3. Look for server actions / constraints with DBM keyword
print("\n--- Server actions mentioning delivery/billing ---")
sa = call("ir.actions.server", "search_read",
    [[["model_id.model", "=", "sale.order"]]],
    {"fields": ["name", "code", "state"], "limit": 50})
for s in sa:
    if any(kw in str(s).lower() for kw in ["delivery", "billing", "dbm", "carrier"]):
        print(f"  [{s['id']}] {s['name']} | state={s['state']}")
        if s.get("code"):
            print(f"    CODE: {s['code'][:300]}")

# 4. Look for installed modules related to sale_delivery_billing
print("\n--- Installed modules with delivery_billing or similar ---")
mods = call("ir.module.module", "search_read",
    [[["state", "=", "installed"], ["name", "ilike", "delivery_billing"]]],
    {"fields": ["name", "summary", "author"], "limit": 20})
for m in mods:
    print(f"  {m['name']}: {m['summary']} ({m['author']})")

# Also check for carrier/billing related
mods2 = call("ir.module.module", "search_read",
    [[["state", "=", "installed"], ["name", "ilike", "sale_delivery"]]],
    {"fields": ["name", "summary", "author"], "limit": 20})
for m in mods2:
    print(f"  {m['name']}: {m['summary']} ({m['author']})")

# 5. Look for any ir.rule or record rules on sale.order
print("\n--- Record rules on sale.order ---")
rules = call("ir.rule", "search_read",
    [[["model_id.model", "=", "sale.order"]]],
    {"fields": ["name", "domain_force", "active", "groups"], "limit": 20})
for r in rules:
    print(f"  [{r['id']}] {r['name']} | active={r['active']}")
    print(f"    domain: {r['domain_force']}")

# 6. Check for Python constraints in sale.order (look for _check methods via ir.model.constraint)
print("\n--- Model constraints on sale.order ---")
constraints = call("ir.model.constraint", "search_read",
    [[["model", "=", "sale.order"]]],
    {"fields": ["name", "type", "definition"], "limit": 20})
for c in constraints:
    print(f"  [{c['id']}] {c['name']} | type={c['type']}")
    if c.get("definition"):
        print(f"    def: {c['definition']}")

print("\n✓ Investigation complete")
