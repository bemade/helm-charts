#!/usr/bin/env python3
"""
odoo-task-queue.py - Check for tasks assigned to Scruffy that need work.

Run as a cron/heartbeat job, outputs JSON for the agent to interpret.
"""

import sys
import json
import asyncio
import subprocess
from datetime import datetime, timezone

sys.path.insert(0, '/home/openclaw/.local/share/uv/tools/bemade-odoo-mcp/lib/python3.12/site-packages')
sys.path.insert(0, '/home/openclaw/.openclaw/workspace')

from scripts.odoo import get_client  # noqa: E402

SCRUFFY_USER_ID = 9446  # Scruffy's Odoo user ID
MARC_USER_ID = 7  # Marc Durepos
BENOIT_USER_ID = 6  # Benoît Vézina


async def check_task_queue():
    """Check for tasks assigned to Scruffy, Marc, or Benoît that need attention."""
    client = get_client()
    
    tasks = []
    
    try:
        # Find tasks assigned to Scruffy in active stages
        # Also include tasks assigned to Marc or Benoît (offer to take over)
        active_tasks = await client.search_read(
            'project.task',
            domain=[
                ('user_ids', 'in', [SCRUFFY_USER_ID, MARC_USER_ID, BENOIT_USER_ID]),
                ('stage_id.fold', '=', False),  # Not in a folded (closed) stage
            ],
            fields=['name', 'project_id', 'stage_id', 'priority', 'date_deadline', 'write_date', 'user_ids'],
            order='priority desc, date_deadline asc',
            limit=30
        )
        
        for task in active_tasks:
            user_ids = task.get('user_ids', [])
            assigned_to = []
            if SCRUFFY_USER_ID in user_ids:
                assigned_to.append('scruffy')
            if MARC_USER_ID in user_ids:
                assigned_to.append('marc')
            if BENOIT_USER_ID in user_ids:
                assigned_to.append('benoit')
            
            tasks.append({
                'id': task['id'],
                'name': task.get('name', 'Unknown'),
                'project': task.get('project_id', [None, 'Unknown'])[1] if task.get('project_id') else 'Unknown',
                'project_id': task.get('project_id', [None])[0] if task.get('project_id') else None,
                'stage': task.get('stage_id', [None, 'Unknown'])[1] if task.get('stage_id') else 'Unknown',
                'stage_id': task.get('stage_id', [None])[0] if task.get('stage_id') else None,
                'priority': task.get('priority', '0'),
                'deadline': task.get('date_deadline'),
                'last_updated': task.get('write_date'),
                'assigned_to': assigned_to,
            })
        
    except Exception as e:
        sys.stderr.write(f"Error checking task queue: {e}\n")
        return []
    
    return tasks


def main():
    tasks = asyncio.run(check_task_queue())
    
    output = {
        'timestamp': datetime.now(timezone.utc).isoformat(),
        'task_count': len(tasks),
        'tasks': tasks,
    }
    
    print(json.dumps(output, indent=2))


if __name__ == '__main__':
    main()