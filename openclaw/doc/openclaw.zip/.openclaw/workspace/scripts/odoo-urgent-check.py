#!/usr/bin/env python3
"""
odoo-urgent-check.py - Check Odoo for urgent items that need Marc's attention.

Run as a cron job, outputs JSON for the agent to interpret.
"""

import sys
import os
import json
import asyncio
import subprocess
from datetime import datetime, timezone, timedelta

sys.path.insert(0, '/home/openclaw/.local/share/uv/tools/bemade-odoo-mcp/lib/python3.12/site-packages')
sys.path.insert(0, '/home/openclaw/.openclaw/workspace')

from odoo_mcp.client import OdooClient  # noqa: E402

ODOO_URL = "https://odoo.bemade.org"
ODOO_DB = "odoo_9354ec71_80d8_4d34_9ca6_7a339acd405f"
MARC_PARTNER_ID = 12  # Marc Durepos
SCRUFFY_PARTNER_ID = 29267  # Scruffy Bot


def get_api_key() -> str:
    result = subprocess.run(
        ["pass", "show", "odoo.bemade.org/api/scruffy@bemade.org"],
        capture_output=True, text=True, check=True
    )
    return result.stdout.splitlines()[0].strip()


async def check_urgent_items():
    """Check for urgent items in Odoo that need attention."""
    key = get_api_key()
    client = OdooClient(
        base_url=ODOO_URL,
        database=ODOO_DB,
        username="scruffy@bemade.org",
        api_key=key,
    )
    
    alerts = []
    
    try:
        
        # Check for unread inbox messages for Scruffy (so I can act on things assigned to me)
        # mail.notification links to mail.message, but we can't read mail.message directly
        # The mail_message_id field includes [id, display_name] so we use that
        unread_notifications = await client.search_read(
            'mail.notification',
            domain=[
                ('res_partner_id', '=', SCRUFFY_PARTNER_ID),
                ('is_read', '=', False),
            ],
            fields=['mail_message_id', 'notification_type'],
            limit=20
        )
        
        for notif in unread_notifications:
            msg_ref = notif.get('mail_message_id')
            if msg_ref:
                # msg_ref is [id, display_name] - use display_name as the message summary
                msg_id = msg_ref[0] if isinstance(msg_ref, list) else msg_ref
                msg_name = msg_ref[1] if isinstance(msg_ref, list) and len(msg_ref) > 1 else str(msg_id)
                alerts.append({
                    'type': 'notification',
                    'message_id': msg_id,
                    'summary': msg_name,
                    'notification_type': notif.get('notification_type'),
                })
        
        # Check for high-priority tasks assigned to Marc
        high_priority_tasks = await client.search_read(
            'project.task',
            domain=[
                ('user_ids', 'in', [MARC_PARTNER_ID]),
                ('priority', '=', '1'),  # High priority
                ('stage_id.name', 'not ilike', 'Done'),
            ],
            fields=['name', 'project_id', 'stage_id', 'priority', 'date_deadline'],
            limit=10
        )
        
        for task in high_priority_tasks:
            alerts.append({
                'type': 'high_priority_task',
                'task_id': task['id'],
                'name': task.get('name', 'Unknown'),
                'project': task.get('project_id', [None, 'Unknown'])[1] if task.get('project_id') else 'Unknown',
                'stage': task.get('stage_id', [None, 'Unknown'])[1] if task.get('stage_id') else 'Unknown',
            })
        
        # Check for tasks with overdue deadlines assigned to Marc
        overdue_tasks = await client.search_read(
            'project.task',
            domain=[
                ('user_ids', 'in', [MARC_PARTNER_ID]),
                ('date_deadline', '<', datetime.now(timezone.utc).strftime('%Y-%m-%d')),
                ('stage_id.name', 'not ilike', 'Done'),
            ],
            fields=['name', 'project_id', 'stage_id', 'date_deadline'],
            limit=10
        )
        
        for task in overdue_tasks:
            if not any(a['type'] == 'overdue_task' and a['task_id'] == task['id'] for a in alerts):
                alerts.append({
                    'type': 'overdue_task',
                    'task_id': task['id'],
                    'name': task.get('name', 'Unknown'),
                    'project': task.get('project_id', [None, 'Unknown'])[1] if task.get('project_id') else 'Unknown',
                    'deadline': task.get('date_deadline'),
                })
        
    except Exception as e:
        sys.stderr.write(f"Error checking Odoo: {e}\n")
        return []
    
    return alerts


def main():
    alerts = asyncio.run(check_urgent_items())
    
    output = {
        'timestamp': datetime.now(timezone.utc).isoformat(),
        'has_urgent': len(alerts) > 0,
        'alert_count': len(alerts),
        'alerts': alerts,
    }
    
    print(json.dumps(output, indent=2))


if __name__ == '__main__':
    main()