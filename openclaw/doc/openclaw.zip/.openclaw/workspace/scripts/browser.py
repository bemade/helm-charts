"""
browser.py — Playwright helper library + CLI for Odoo browser automation.

Library usage:
    import sys
    sys.path.insert(0, '/home/openclaw/.openclaw/workspace')
    from scripts.browser import OdooBrowser

    async with OdooBrowser() as b:
        await b.login()
        await b.goto("/odoo/project")
        path = await b.screenshot("project-list")
        errors = await b.console_errors()
        html = await b.page_source()
        await b.fill('input[name="name"]', "Test")
        await b.click('button.btn-primary')

CLI usage:
    python3 scripts/browser.py screenshot --url /odoo/project [--out screenshots/test.png]
    python3 scripts/browser.py errors --url /odoo/project
    python3 scripts/browser.py dump --url /odoo/project
"""

import sys
import os
import asyncio
import argparse
import subprocess
from datetime import datetime
from pathlib import Path

# Ensure Playwright is importable from the uv tool installation
PLAYWRIGHT_SITE_PACKAGES = (
    "/home/openclaw/.local/share/uv/tools/playwright/lib/python3.12/site-packages"
)
if PLAYWRIGHT_SITE_PACKAGES not in sys.path:
    sys.path.insert(0, PLAYWRIGHT_SITE_PACKAGES)

from playwright.async_api import async_playwright, Page, Browser, BrowserContext

BASE_URL = "https://odoo.bemade.org"
LOGIN_EMAIL = "scruffy@bemade.org"
PASS_ENTRY = "odoo.bemade.org/scruffy@bemade.org"
SCREENSHOTS_DIR = Path("/home/openclaw/.openclaw/workspace/screenshots")


def _get_password() -> str:
    """Read password from `pass` password store."""
    result = subprocess.run(
        ["pass", "show", PASS_ENTRY],
        capture_output=True,
        text=True,
        check=True,
    )
    return result.stdout.strip().splitlines()[0]


class OdooBrowser:
    """
    Async context manager for headless Chromium browser automation against Odoo.

    Usage:
        async with OdooBrowser() as b:
            await b.login()
            await b.goto("/odoo/project")
            path = await b.screenshot("project-list")
    """

    def __init__(
        self,
        base_url: str = BASE_URL,
        headless: bool = True,
        slow_mo: int = 0,
        timeout: int = 30_000,
    ):
        self.base_url = base_url.rstrip("/")
        self.headless = headless
        self.slow_mo = slow_mo
        self.default_timeout = timeout

        self._playwright = None
        self._browser: Browser | None = None
        self._context: BrowserContext | None = None
        self.page: Page | None = None

        self._console_messages: list[dict] = []
        self._network_errors: list[dict] = []

        SCREENSHOTS_DIR.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------ #
    # Context manager                                                       #
    # ------------------------------------------------------------------ #

    async def __aenter__(self) -> "OdooBrowser":
        self._playwright = await async_playwright().start()
        self._browser = await self._playwright.chromium.launch(
            headless=self.headless,
            slow_mo=self.slow_mo,
            args=["--no-sandbox", "--disable-setuid-sandbox"],
        )
        self._context = await self._browser.new_context(
            viewport={"width": 1440, "height": 900},
            locale="en_US",
        )
        self._context.set_default_timeout(self.default_timeout)
        self.page = await self._context.new_page()
        self._attach_listeners()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None and self.page:
            # Auto-screenshot on error
            try:
                ts = datetime.now().strftime("%Y%m%d-%H%M%S")
                err_path = SCREENSHOTS_DIR / f"error-{ts}.png"
                await self.page.screenshot(path=str(err_path), full_page=True)
                print(f"[browser] Error screenshot saved: {err_path}", file=sys.stderr)
            except Exception:
                pass
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()

    # ------------------------------------------------------------------ #
    # Internal helpers                                                      #
    # ------------------------------------------------------------------ #

    def _attach_listeners(self):
        """Attach console and network error listeners to the page."""

        def _on_console(msg):
            if msg.type in ("error", "warning"):
                self._console_messages.append(
                    {"type": msg.type, "text": msg.text, "url": self.page.url}
                )

        def _on_pageerror(exc):
            self._console_messages.append(
                {"type": "pageerror", "text": str(exc), "url": self.page.url}
            )

        def _on_requestfailed(request):
            self._network_errors.append(
                {
                    "url": request.url,
                    "failure": request.failure,
                    "method": request.method,
                }
            )

        self.page.on("console", _on_console)
        self.page.on("pageerror", _on_pageerror)
        self.page.on("requestfailed", _on_requestfailed)

    def _full_url(self, path: str) -> str:
        if path.startswith("http"):
            return path
        if path.startswith("/"):
            return self.base_url + path
        return self.base_url + "/" + path

    # ------------------------------------------------------------------ #
    # Public API                                                            #
    # ------------------------------------------------------------------ #

    async def login(self, email: str = LOGIN_EMAIL, password: str | None = None) -> None:
        """Log in to Odoo using credentials from `pass` (or explicit args)."""
        if password is None:
            password = _get_password()
        await self.page.goto(self.base_url + "/web/login")
        await self.page.wait_for_load_state("networkidle")
        await self.page.fill('input[name="login"]', email)
        await self.page.fill('input[name="password"]', password)
        await self.page.click('button[type="submit"]')
        await self.page.wait_for_load_state("networkidle")

    async def goto(self, path: str, wait: str = "networkidle") -> None:
        """Navigate to an Odoo path (e.g. '/odoo/project')."""
        url = self._full_url(path)
        await self.page.goto(url)
        await self.page.wait_for_load_state(wait)

    async def screenshot(
        self, name: str | None = None, out: str | Path | None = None, full_page: bool = True
    ) -> Path:
        """
        Take a screenshot and return the saved path.

        Args:
            name: Base name (no extension). Defaults to timestamp.
            out:  Explicit output path (overrides name + default dir).
            full_page: Capture full scrollable page.
        """
        if out:
            path = Path(out)
            path.parent.mkdir(parents=True, exist_ok=True)
        else:
            ts = datetime.now().strftime("%Y%m%d-%H%M%S")
            stem = name or ts
            path = SCREENSHOTS_DIR / f"{stem}.png"

        await self.page.screenshot(path=str(path), full_page=full_page)
        return path

    async def console_errors(self) -> list[dict]:
        """Return all collected console errors and warnings so far."""
        return list(self._console_messages)

    async def network_errors(self) -> list[dict]:
        """Return all collected network errors so far."""
        return list(self._network_errors)

    async def page_source(self) -> str:
        """Return the current page's outer HTML."""
        return await self.page.content()

    async def fill(self, selector: str, value: str) -> None:
        """Fill an input field."""
        await self.page.fill(selector, value)

    async def click(self, selector: str) -> None:
        """Click an element."""
        await self.page.click(selector)

    async def wait_for_selector(self, selector: str, **kwargs) -> None:
        """Wait for a selector to appear."""
        await self.page.wait_for_selector(selector, **kwargs)

    async def evaluate(self, expression: str):
        """Evaluate JavaScript in the page context."""
        return await self.page.evaluate(expression)

    def clear_errors(self) -> None:
        """Clear accumulated console and network error logs."""
        self._console_messages.clear()
        self._network_errors.clear()


# ------------------------------------------------------------------ #
# CLI                                                                   #
# ------------------------------------------------------------------ #


async def _cmd_screenshot(args):
    async with OdooBrowser() as b:
        await b.login()
        await b.goto(args.url)
        out = args.out
        path = await b.screenshot(out=out)
        size = path.stat().st_size
        print(f"Screenshot saved: {path} ({size:,} bytes)")
        if size < 10_240:
            print("WARNING: screenshot is smaller than 10 KB — may be blank or errored.")


async def _cmd_errors(args):
    async with OdooBrowser() as b:
        await b.login()
        await b.goto(args.url)
        console_errs = await b.console_errors()
        net_errs = await b.network_errors()

        if console_errs:
            print(f"\n=== Console errors/warnings ({len(console_errs)}) ===")
            for e in console_errs:
                print(f"  [{e['type']}] {e['text']}")
        else:
            print("No console errors or warnings.")

        if net_errs:
            print(f"\n=== Network errors ({len(net_errs)}) ===")
            for e in net_errs:
                print(f"  [{e['method']}] {e['url']}  → {e['failure']}")
        else:
            print("No network errors.")


async def _cmd_dump(args):
    async with OdooBrowser() as b:
        await b.login()
        await b.goto(args.url)
        html = await b.page_source()

        if args.out:
            out = Path(args.out)
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(html, encoding="utf-8")
            print(f"HTML saved to: {out} ({len(html):,} chars)")
        else:
            print(html)


def main():
    parser = argparse.ArgumentParser(
        description="Odoo Playwright browser debugging toolkit",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # screenshot
    p_ss = sub.add_parser("screenshot", help="Take a screenshot of an Odoo URL")
    p_ss.add_argument("--url", required=True, help="Odoo path, e.g. /odoo/project")
    p_ss.add_argument("--out", default=None, help="Output file path (default: screenshots/<ts>.png)")

    # errors
    p_err = sub.add_parser("errors", help="Report JS console and network errors at a URL")
    p_err.add_argument("--url", required=True, help="Odoo path, e.g. /odoo/project")

    # dump
    p_dump = sub.add_parser("dump", help="Dump page HTML source")
    p_dump.add_argument("--url", required=True, help="Odoo path, e.g. /odoo/project")
    p_dump.add_argument("--out", default=None, help="Save to file instead of stdout")

    args = parser.parse_args()

    dispatch = {
        "screenshot": _cmd_screenshot,
        "errors": _cmd_errors,
        "dump": _cmd_dump,
    }
    asyncio.run(dispatch[args.command](args))


if __name__ == "__main__":
    main()
