#!/usr/bin/env python3
"""Post investigation findings to Task 3312."""
import sys, asyncio
sys.path.insert(0, '/home/openclaw/.openclaw/workspace')
from scripts.odoo import get_client, post_message

# Build message from parts to avoid triple-quote conflicts
parts = [
    "<h3>&#x1F50D; Investigation: Blocage DBM sur le portail client</h3>",
    "<p><strong>Mcanisme bloquant identifi &mdash; fichier: <code>pneumac_sale/models/sale_order.py</code></strong></p>",
    "<p>C'est un <strong>@api.constrains Python</strong> (pas un automated action, pas une rgle SQL). "
    "Il se dclenche ds que <code>state</code> passe  <code>'sale'</code> :</p>",
    "<pre>@api.constrains('state', 'delivery_billing_mode')\n"
    "def _require_delivery_billing_mode_when_confirmed(self):\n"
    "    for order in self:\n"
    "        if order.state == 'sale' and not order.delivery_billing_mode:\n"
    "            raise ValidationError(\n"
    "                _(\"Delivery billing mode is required when the order is confirmed.\")\n"
    "            )</pre>",
    "<p>Quand le client clique <strong>Accept &amp; Sign</strong> sur le portail :</p>",
    "<ol>"
    "<li>Odoo appelle <code>action_confirm()</code> sur le SO</li>"
    "<li>Le state passe  <code>'sale'</code></li>"
    "<li>La contrainte se dclenche</li>"
    "<li>La soumission a t envoye sans DBM &rarr; <code>ValidationError</code></li>"
    "<li>Le portail ne gre pas cette erreur proprement &rarr; <strong>loading infini ct client</strong></li>"
    "</ol>",
    "<hr/>",
    "<h3>&#x1F6E0; Solution recommande: Auto-dfaut &quot;Prepaid&quot; dans action_confirm()</h3>",
    "<p>La correction la plus simple : auto-set <code>delivery_billing_mode = 'prepaid'</code> "
    "si pas de valeur, avant d'appeler <code>super()</code>. "
    "Ce pattern existe dj dans <code>sale_mandatory_customer_reference</code> "
    "qui fait pareil avec &quot;Credit Card&quot; pour les paiements en ligne.</p>",
    "<p><strong>Fichier  modifier: <code>pneumac_sale/models/sale_order.py</code></strong></p>",
    "<p>Ajouter au dbut de <code>action_confirm()</code>, avant le bloc <code>skip_tax_warning</code> :</p>",
    "<pre># Auto-set delivery billing mode for orders without one (e.g. portal acceptance)\n"
    "for order in self:\n"
    "    if not order.delivery_billing_mode:\n"
    "        order.delivery_billing_mode = 'prepaid'</pre>",
    "<hr/>",
    "<h3>&#x1F4DD; Test  mettre  jour</h3>",
    "<p>Le test <code>test_action_confirm_without_delivery_billing_mode_raises_error</code> "
    "doit devenir :</p>",
    "<pre>def test_action_confirm_without_delivery_billing_mode_sets_prepaid_default(self):\n"
    "    order = self._create_sale_order(delivery_billing_mode=False)\n"
    "    self.assertFalse(order.delivery_billing_mode)\n"
    "    order.action_confirm()\n"
    "    self.assertEqual(order.state, 'sale')\n"
    "    self.assertEqual(order.delivery_billing_mode, 'prepaid')</pre>",
    "<hr/>",
    "<h3>&#x1F4CC; Notes additionnelles</h3>",
    "<ul>"
    "<li>La valeur 'prepaid' est valide (slection: no charge / ppc / prepaid / collect / third party)</li>"
    "<li>Fix aussi les cas backend o un vendeur confirme accidentellement sans DBM</li>"
    "<li>Le champ <code>delivery_billing_mode</code> vient du module standard Odoo <code>delivery</code></li>"
    "<li>Pas de champ DBM sur <code>res.partner</code> &mdash; dfaut par partenaire = plus de travail</li>"
    "<li>Pour DBM sur le portail: s'inspirer de <code>sale_mandatory_customer_reference/controllers/portal.py</code></li>"
    "</ul>",
    "<p><em>&mdash; Scruffy Bot (analyse via API + code source)</em></p>",
]

MESSAGE = "\n".join(parts)

async def main():
    client = get_client()
    try:
        await post_message(client, 'project.task', 3312, body_html=MESSAGE)
        print("Posted to task 3312")
    finally:
        await client.close()

asyncio.run(main())
