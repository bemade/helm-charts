#!/usr/bin/env python3
"""Post an internal note to a project task."""

import sys
import asyncio

sys.path.insert(0, '/home/openclaw/.openclaw/workspace')
from scripts.odoo import get_client, post_message


async def main():
    task_id = int(sys.argv[1])
    body = sys.argv[2]
    
    client = get_client()
    try:
        result = await post_message(
            client,
            'project.task',
            task_id,
            body_html=body,
            internal=True,  # Internal note, not client-visible
        )
        print(f"Posted note to task {task_id}")
    finally:
        await client.close()


if __name__ == "__main__":
    asyncio.run(main())