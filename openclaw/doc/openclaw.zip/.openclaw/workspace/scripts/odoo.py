#!/usr/bin/env python3
"""
odoo.py - Reusable Odoo helper for Scruffy OpenClaw agent.

Library usage (async):
    from scripts.odoo import get_client, create, post_message
    client = get_client()
    async with client:
        records = await client.search_read('res.partner', limit=5)

CLI usage:
    python3 scripts/odoo.py models [--filter sale]
    python3 scripts/odoo.py fields res.partner
    python3 scripts/odoo.py search res.partner [--domain '[[...]]'] [--fields name,email] [--limit 10]
    python3 scripts/odoo.py read res.partner 1,2,3 [--fields name,email]
"""

import sys
import os
import json
import asyncio
import subprocess
import argparse

# Inject the bemade-odoo-mcp site-packages
sys.path.insert(0, '/home/openclaw/.local/share/uv/tools/bemade-odoo-mcp/lib/python3.12/site-packages')

from odoo_mcp.client import OdooClient  # noqa: E402

# --- Config defaults --------------------------------------------------------

ODOO_URL = os.environ.get("ODOO_URL", "https://odoo.bemade.org")
ODOO_DB = os.environ.get("ODOO_DB", "odoo_9354ec71_80d8_4d34_9ca6_7a339acd405f")
ODOO_USERNAME = "scruffy@bemade.org"


# --- Credential helpers -----------------------------------------------------

def _pass_show(path: str) -> str | None:
    """Read the first line of a pass entry. Returns None on failure."""
    try:
        result = subprocess.run(
            ["pass", "show", path],
            capture_output=True, text=True, check=True
        )
        lines = result.stdout.splitlines()
        return lines[0].strip() if lines else None
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None


def _get_api_key() -> str | None:
    """Return API key from env or pass store."""
    return os.environ.get("ODOO_API_KEY") or _pass_show("odoo.bemade.org/api/scruffy@bemade.org")


def _get_password() -> str | None:
    """Return password from pass store."""
    return _pass_show("odoo.bemade.org/scruffy@bemade.org")


# --- Client factory ---------------------------------------------------------

def get_client() -> OdooClient:
    """
    Return a configured OdooClient.
    Bearer (API key) is preferred; falls back to username/password session.
    Reads credentials from `pass` automatically.
    Env vars ODOO_URL, ODOO_API_KEY, ODOO_DB override defaults.
    """
    api_key = _get_api_key()
    if api_key:
        return OdooClient(
            base_url=ODOO_URL,
            api_key=api_key,
            database=ODOO_DB,
        )
    # Fallback to password
    password = _get_password()
    if not password:
        raise RuntimeError(
            "No Odoo credentials found. "
            "Set ODOO_API_KEY or ensure `pass` is configured with odoo.bemade.org entries."
        )
    return OdooClient(
        base_url=ODOO_URL,
        username=ODOO_USERNAME,
        password=password,
        database=ODOO_DB,
    )


# --- create() workaround for Odoo 19 bug ------------------------------------

async def create(client: OdooClient, model: str, vals: dict) -> int:
    """
    Create a record, working around OdooClient.create()'s bug where vals_list
    is sent as a dict. Odoo 19 requires vals_list to be a list.

    Uses raw JSON-RPC/JSON-2 directly.

    Returns the new record ID.
    """
    # Ensure the underlying httpx client is initialized (and authenticated if session mode)
    http_client = await client._get_client()

    if client._use_bearer:
        # JSON-2 endpoint: send vals_list as a list (not dict)
        response = await http_client.post(
            f"/json/2/{model}/create",
            json={"vals_list": [vals]}
        )
        if response.status_code >= 400:
            raise RuntimeError(f"create() failed [{response.status_code}]: {response.text[:500]}")
        result = response.json()
    else:
        # JSON-RPC: positional args = [[vals]], kwargs = {}
        payload = {
            "jsonrpc": "2.0",
            "method": "call",
            "id": next(client._jsonrpc_id),
            "params": {
                "model": model,
                "method": "create",
                "args": [[vals]],
                "kwargs": {},
            }
        }
        response = await http_client.post(
            f"/web/dataset/call_kw/{model}/create",
            json=payload
        )
        if response.status_code >= 400:
            raise RuntimeError(f"create() failed [{response.status_code}]: {response.text[:500]}")
        data = response.json()
        if "error" in data:
            from odoo_mcp.client import _extract_jsonrpc_error
            raise RuntimeError(f"create() error: {_extract_jsonrpc_error(data)}")
        result = data.get("result")

    if isinstance(result, list):
        return result[0]
    return result


# --- message_post helper ----------------------------------------------------

def format_mention(partner_id: int, name: str) -> str:
    """
    Format a partner mention as an Odoo HTML anchor tag.

    Usage: body = f"Hello {format_mention(42, 'Marc Durepos')}, see below."
    """
    return (
        f'<a href="/odoo/res.partner/{partner_id}" '
        f'class="o_mail_redirect" '
        f'data-oe-id="{partner_id}" '
        f'data-oe-model="res.partner" '
        f'target="_blank" '
        f'contenteditable="false">@{name}</a>'
    )


async def post_message(
    client: OdooClient,
    model: str,
    res_id: int,
    body_html: str,
    mention_partner_ids: list[int] | None = None,
    internal: bool = True,
) -> dict:
    """
    Post a chatter message on an Odoo record.

    Args:
        client:              OdooClient instance
        model:               e.g. 'project.task', 'sale.order'
        res_id:              ID of the record to post on
        body_html:           HTML message body (use format_mention() for @mentions)
        mention_partner_ids: Optional list of partner IDs to notify
        internal:            If True (default), posts as internal note (mail.mt_note).
                             Set False only when Marc has explicitly approved client-visible message.

    IMPORTANT: Clients are often followers on their own tasks/projects.
    Default to internal=True to avoid inadvertently notifying clients.
    Only set internal=False with Marc's explicit approval.

    The body_is_html=True flag is set automatically so HTML renders correctly.
    Uses ids=[res_id] (not a kwarg) as required by Odoo 19.
    """
    kwargs: dict = {
        "body": body_html,
        "body_is_html": True,
        "subtype_xmlid": "mail.mt_note" if internal else "mail.mt_comment",
    }
    if mention_partner_ids:
        kwargs["partner_ids"] = mention_partner_ids

    return await client.execute(
        model,
        "message_post",
        ids=[res_id],
        **kwargs,
    )


# --- CLI commands -----------------------------------------------------------

async def cmd_models(args) -> None:
    """
    List Odoo models. Tries ir.model first (requires Access Rights group).
    Falls back to the doc-bearer index if available.
    Scruffy's API key may not have ir.model access — check group membership if needed.
    """
    client = get_client()
    try:
        # Try ir.model (requires "Access Rights" group)
        domain: list = []
        if args.filter:
            domain = ["|",
                      ["model", "ilike", args.filter],
                      ["name", "ilike", args.filter]]
        try:
            results = await client.search_read(
                "ir.model",
                domain=domain,
                fields=["model", "name"],
                limit=500,
            )
            results.sort(key=lambda r: r.get("model", ""))
            print(json.dumps(results, indent=2, ensure_ascii=False))
            return
        except Exception as e:
            if "not allowed" in str(e).lower() or "403" in str(e):
                # ir.model access denied, try doc index
                pass
            else:
                raise

        # Fallback: doc index
        try:
            doc = await client.get_doc_index()
            models = doc if isinstance(doc, list) else doc.get("models", [])
            if args.filter:
                f = args.filter.lower()
                models = [m for m in models if f in str(m).lower()]
            print(json.dumps(models, indent=2, ensure_ascii=False))
            return
        except Exception:
            pass

        # Nothing worked
        print(json.dumps({
            "error": "models listing unavailable",
            "note": (
                "scruffy@bemade.org needs the 'Access Rights' group to list ir.model. "
                "Use `fields <model>` on known model names instead."
            )
        }, indent=2))
    finally:
        await client.close()


async def cmd_fields(args) -> None:
    client = get_client()
    try:
        result = await client.fields_get(
            args.model,
            attributes=["string", "type", "required", "readonly", "help"],
        )
        print(json.dumps(result, indent=2, ensure_ascii=False))
    finally:
        await client.close()


async def cmd_search(args) -> None:
    client = get_client()
    try:
        domain = json.loads(args.domain) if args.domain else []
        fields = args.fields.split(",") if args.fields else None
        limit = args.limit if args.limit is not None else 10
        result = await client.search_read(
            args.model,
            domain=domain,
            fields=fields,
            limit=limit,
        )
        print(json.dumps(result, indent=2, ensure_ascii=False))
    finally:
        await client.close()


async def cmd_read(args) -> None:
    client = get_client()
    try:
        ids = [int(i.strip()) for i in args.ids.split(",")]
        fields = args.fields.split(",") if args.fields else None
        result = await client.read(args.model, ids=ids, fields=fields)
        print(json.dumps(result, indent=2, ensure_ascii=False))
    finally:
        await client.close()


# --- Entry point ------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Odoo CLI helper (Scruffy / bemade.org)"
    )
    subs = parser.add_subparsers(dest="command", metavar="COMMAND")

    # models
    p_models = subs.add_parser("models", help="List available models")
    p_models.add_argument("--filter", metavar="TEXT", help="Filter by model/name substring")

    # fields
    p_fields = subs.add_parser("fields", help="Get field definitions for a model")
    p_fields.add_argument("model")

    # search
    p_search = subs.add_parser("search", help="Search records with optional domain")
    p_search.add_argument("model")
    p_search.add_argument("--domain", metavar="JSON",
                          help='JSON domain, e.g. \'[["active","=",true]]\'')
    p_search.add_argument("--fields", metavar="f1,f2",
                          help="Comma-separated field names to return")
    p_search.add_argument("--limit", type=int, default=10,
                          help="Max records to return (default: 10)")

    # read
    p_read = subs.add_parser("read", help="Read specific records by ID")
    p_read.add_argument("model")
    p_read.add_argument("ids", help="Comma-separated record IDs")
    p_read.add_argument("--fields", metavar="f1,f2",
                        help="Comma-separated field names to return")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    dispatch = {
        "models": cmd_models,
        "fields": cmd_fields,
        "search": cmd_search,
        "read": cmd_read,
    }

    asyncio.run(dispatch[args.command](args))


if __name__ == "__main__":
    main()
