#!/usr/bin/env python3
"""
staging-durpro.py - Reusable Odoo helper for staging.durpro.com (Odoo 17, JSON-RPC).

Uses classic JSON-RPC (not /json/2/) because staging runs Odoo 17 or earlier.
"""

import sys
import os
import json
import asyncio
import subprocess
import argparse
from typing import Any

# Staging Durpro config
STAGING_URL = "https://staging.durpro.com"
STAGING_DB = "odoo_91304d71_d1d2_40d9_8c6d_ae6b589970fb"


def get_password() -> str:
    """Get password from pass store."""
    result = subprocess.run(
        ["pass", "show", "staging.durpro.com/admin"],
        capture_output=True, text=True, check=True
    )
    return result.stdout.splitlines()[0].strip()


def jsonrpc_call(service: str, method: str, *args) -> Any:
    """Make a JSON-RPC call to staging.durpro.com."""
    import urllib.request
    import urllib.error
    
    password = get_password()
    url = f"{STAGING_URL}/jsonrpc"
    
    payload = {
        "jsonrpc": "2.0",
        "method": "call",
        "params": {
            "service": service,
            "method": method,
            "args": list(args)
        },
        "id": 1
    }
    
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            if "error" in result:
                raise Exception(f"Odoo error: {result['error']}")
            return result.get("result")
    except urllib.error.HTTPError as e:
        raise Exception(f"HTTP {e.code}: {e.read().decode('utf-8')[:500]}")


def get_uid() -> int:
    """Authenticate and get user ID."""
    password = get_password()
    result = jsonrpc_call("common", "authenticate", STAGING_DB, "admin", password, {})
    if not result:
        raise Exception("Authentication failed")
    return result


def search(model: str, domain: list, limit: int = 10, offset: int = 0, order: str = None) -> list:
    """Search for records."""
    uid = get_uid()
    password = get_password()
    kwargs = {"limit": limit, "offset": offset}
    if order:
        kwargs["order"] = order
    return jsonrpc_call("object", "execute_kw", STAGING_DB, uid, password, model, "search", [domain], kwargs)


def search_read(model: str, domain: list, fields: list = None, limit: int = 10, offset: int = 0, order: str = None) -> list:
    """Search and read records."""
    uid = get_uid()
    password = get_password()
    kwargs = {"limit": limit, "offset": offset}
    if fields:
        kwargs["fields"] = fields
    if order:
        kwargs["order"] = order
    return jsonrpc_call("object", "execute_kw", STAGING_DB, uid, password, model, "search_read", [domain], kwargs)


def read(model: str, ids: list, fields: list = None) -> list:
    """Read records by ID."""
    uid = get_uid()
    password = get_password()
    kwargs = {}
    if fields:
        kwargs["fields"] = fields
    return jsonrpc_call("object", "execute_kw", STAGING_DB, uid, password, model, "read", [ids], kwargs)


def fields_get(model: str, attributes: list = None) -> dict:
    """Get field definitions for a model."""
    uid = get_uid()
    password = get_password()
    kwargs = {}
    if attributes:
        kwargs["attributes"] = attributes
    return jsonrpc_call("object", "execute_kw", STAGING_DB, uid, password, model, "fields_get", [], kwargs)


def write(model: str, ids: list, vals: dict) -> bool:
    """Write to records."""
    uid = get_uid()
    password = get_password()
    return jsonrpc_call("object", "execute_kw", STAGING_DB, uid, password, model, "write", [ids, vals])


def create(model: str, vals: dict) -> int:
    """Create a record."""
    uid = get_uid()
    password = get_password()
    return jsonrpc_call("object", "execute_kw", STAGING_DB, uid, password, model, "create", [vals])


def unlink(model: str, ids: list) -> bool:
    """Delete records."""
    uid = get_uid()
    password = get_password()
    return jsonrpc_call("object", "execute_kw", STAGING_DB, uid, password, model, "unlink", [ids])


# CLI interface
def main():
    parser = argparse.ArgumentParser(description="Staging Durpro Odoo CLI")
    subparsers = parser.add_subparsers(dest="command", help="Command")
    
    # Search command
    search_parser = subparsers.add_parser("search", help="Search records")
    search_parser.add_argument("model", help="Model name")
    search_parser.add_argument("--domain", "-d", default="[]", help="JSON domain")
    search_parser.add_argument("--fields", "-f", help="Comma-separated fields")
    search_parser.add_argument("--limit", "-l", type=int, default=10, help="Limit")
    
    # Read command
    read_parser = subparsers.add_parser("read", help="Read records")
    read_parser.add_argument("model", help="Model name")
    read_parser.add_argument("ids", help="Comma-separated IDs")
    read_parser.add_argument("--fields", "-f", help="Comma-separated fields")
    
    # Fields command
    fields_parser = subparsers.add_parser("fields", help="Get model fields")
    fields_parser.add_argument("model", help="Model name")
    fields_parser.add_argument("--filter", "-f", help="Filter field names")
    
    args = parser.parse_args()
    
    if args.command == "search":
        domain = json.loads(args.domain)
        fields = args.fields.split(",") if args.fields else None
        result = search_read(args.model, domain, fields=fields, limit=args.limit)
        print(json.dumps(result, indent=2, default=str))
    elif args.command == "read":
        ids = [int(x) for x in args.ids.split(",")]
        fields = args.fields.split(",") if args.fields else None
        result = read(args.model, ids, fields=fields)
        print(json.dumps(result, indent=2, default=str))
    elif args.command == "fields":
        result = fields_get(args.model)
        if args.filter:
            result = {k: v for k, v in result.items() if args.filter.lower() in k.lower()}
        print(json.dumps(result, indent=2, default=str))
    else:
        parser.print_help()


if __name__ == "__main__":
    main()