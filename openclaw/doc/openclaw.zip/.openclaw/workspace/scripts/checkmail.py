#!/usr/bin/env python3
"""
checkmail.py - Simple IMAP reader for scruffy@bemade.org
Usage: python3 checkmail.py [--unread] [--limit 10] [--folder INBOX]
"""
import imaplib, email, subprocess, argparse, sys
from email.header import decode_header

def get_password():
    result = subprocess.run(
        ["pass", "show", "mail01.durpro.com/scruffy@bemade.org"],
        capture_output=True, text=True
    )
    return result.stdout.strip().splitlines()[0]

def decode_str(s):
    if s is None:
        return ""
    parts = decode_header(s)
    out = []
    for part, enc in parts:
        if isinstance(part, bytes):
            out.append(part.decode(enc or "utf-8", errors="replace"))
        else:
            out.append(part)
    return "".join(out)

def check_mail(unread_only=True, limit=10, folder="INBOX"):
    password = get_password()
    mail = imaplib.IMAP4_SSL("mail01.durpro.com", 993)
    mail.login("scruffy@bemade.org", password)
    mail.select(folder)

    criteria = "UNSEEN" if unread_only else "ALL"
    status, data = mail.search(None, criteria)
    ids = data[0].split()
    ids = ids[-limit:]  # most recent

    if not ids:
        print(f"No {'unread ' if unread_only else ''}messages in {folder}.")
        mail.logout()
        return

    for uid in reversed(ids):
        status, msg_data = mail.fetch(uid, "(RFC822)")
        msg = email.message_from_bytes(msg_data[0][1])
        subject = decode_str(msg.get("Subject", "(no subject)"))
        sender  = decode_str(msg.get("From", ""))
        date    = msg.get("Date", "")
        print(f"[{uid.decode()}] {date}")
        print(f"  From: {sender}")
        print(f"  Subj: {subject}")
        print()

    mail.logout()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--unread", action="store_true", default=True)
    parser.add_argument("--all", action="store_true")
    parser.add_argument("--limit", type=int, default=10)
    parser.add_argument("--folder", default="INBOX")
    args = parser.parse_args()
    check_mail(unread_only=not args.all, limit=args.limit, folder=args.folder)
