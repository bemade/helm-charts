#!/usr/bin/env python3
"""
Deep dive: Find the DBM blocking constraint - Part 3
"""
import json
import urllib.request

URL = "https://staging.pneumac.qc.ca"
DB = "odoo_91aea74e_be15_4e57_a7bb_c47fd9727b99"
ADMIN_KEY = "551a54d37a6040d144d4830b037a340af4440122"

def rpc(service, method, args):
    payload = json.dumps({
        "jsonrpc": "2.0",
        "method": "call",
        "params": {"service": service, "method": method, "args": args}
    }).encode()
    req = urllib.request.Request(f"{URL}/jsonrpc", data=payload,
        headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        result = json.loads(resp.read())
    if "error" in result:
        raise RuntimeError(f"RPC: {result['error']['data']['message']}")
    return result["result"]

uid = rpc("common", "authenticate", [DB, "admin", ADMIN_KEY, {}])
def call(model, method, args=None, kwargs=None):
    return rpc("object", "execute_kw", [DB, uid, ADMIN_KEY, model, method, args or [], kwargs or {}])

# 1. Check automated action details (get action server code)
print("=== Automated Action Details ===")
for aa_id in [19, 22]:
    aa = call("base.automation", "read", [[aa_id]], {"fields": ["name", "trigger", "active", "action_server_ids", "filter_pre_domain", "filter_domain", "trigger_field_ids"]})[0]
    print(f"\n[{aa_id}] {aa['name']}")
    print(f"  trigger: {aa['trigger']}, active: {aa['active']}")
    print(f"  filter_pre: {aa.get('filter_pre_domain')}")
    print(f"  filter: {aa.get('filter_domain')}")
    # Get action server code
    if aa.get("action_server_ids"):
        for srv_id in aa["action_server_ids"]:
            srv = call("ir.actions.server", "read", [[srv_id]], {"fields": ["name", "state", "code"]})[0]
            print(f"  Server action [{srv_id}] {srv['name']} | {srv['state']}")
            if srv.get("code"):
                print(f"  CODE:\n{srv['code']}")

# 2. Look for ALL custom modules from Bemade/Pneumac
print("\n=== Custom modules (non-standard) ===")
mods = call("ir.module.module", "search_read",
    [[["state", "=", "installed"], ["author", "not ilike", "Odoo"], ["author", "not ilike", "OCA"]]],
    {"fields": ["name", "summary", "author"], "order": "name", "limit": 200})
for m in mods:
    print(f"  [{m['id']}] {m['name']} | {m['author']}")
    if m.get("summary"):
        print(f"       → {m['summary']}")

# 3. Look for the sale_mandatory_customer_reference module details
print("\n=== Module: sale_mandatory_customer_reference ===")
mod_details = call("ir.module.module", "search_read",
    [[["name", "=", "sale_mandatory_customer_reference"]]],
    {"fields": ["name", "summary", "description", "author", "installed_version"]})[0]
print(json.dumps(mod_details, indent=2))

# 4. Check ALL automated actions - full list
print("\n=== All base.automation on sale.order (full) ===")
aas = call("base.automation", "search_read",
    [[["model_id.model", "=", "sale.order"]]],
    {"fields": ["name", "trigger", "active", "filter_pre_domain", "filter_domain", "action_server_ids"], "limit": 100})
for a in aas:
    print(f"\n  [{a['id']}] {a['name']} | trigger={a['trigger']} | active={a['active']}")
    if a.get("filter_pre_domain"):
        print(f"    filter_pre: {a['filter_pre_domain']}")
    if a.get("filter_domain"):
        print(f"    filter: {a['filter_domain']}")
    for srv_id in (a.get("action_server_ids") or []):
        srv = call("ir.actions.server", "read", [[srv_id]], {"fields": ["name", "state", "code", "groups_id"]})[0]
        print(f"    → [{srv_id}] {srv['name']} ({srv['state']})")
        if srv.get("code"):
            print(f"      CODE: {srv['code'][:500]}")

# 5. Check for Python constraints in ir.model.constraint (type='c' = Python, type='u' = SQL unique, type='f' = foreign key, type='check' = SQL check)
print("\n=== ALL constraints on sale.order ===")
consts = call("ir.model.constraint", "search_read",
    [[["model", "=", "sale.order"]]],
    {"fields": ["name", "type", "definition", "message", "module"], "limit": 100})
for c in consts:
    if c['type'] not in ['f', 'u']:  # skip FK and unique - focus on check and python
        print(f"  [{c['id']}] type={c['type']} | name={c['name']} | module={c.get('module')}")
        if c.get("definition"):
            print(f"    def: {c['definition']}")
        if c.get("message"):
            print(f"    msg: {c['message']}")
# Also show check constraints
for c in consts:
    if c['type'] == 'u' and 'delivery' in c['name'].lower():
        print(f"  [{c['id']}] UNIQUE: {c['name']}")

# 6. Check res.partner for delivery_billing_mode default
print("\n=== res.partner fields related to delivery/billing ===")
partner_fields = call("res.partner", "fields_get", [], {"attributes": ["string", "type", "required", "default"]})
dbm_partner_fields = {k: v for k, v in partner_fields.items() 
    if any(kw in k.lower() for kw in ["delivery", "billing", "carrier", "transport", "prepaid", "dbm"])}
for fname, finfo in dbm_partner_fields.items():
    print(f"  {fname}: {finfo}")

print("\n✓ Done")
