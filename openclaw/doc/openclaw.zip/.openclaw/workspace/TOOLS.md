# TOOLS.md - Local Notes

Skills define _how_ tools work. This file is for _your_ specifics — the stuff that's unique to your setup.

## What Goes Here

Things like:

- Camera names and locations
- SSH hosts and aliases
- Preferred voices for TTS
- Speaker/room names
- Device nicknames
- Anything environment-specific

## Examples

```markdown
### Cameras

- living-room → Main area, 180° wide angle
- front-door → Entrance, motion-triggered

### SSH

- home-server → 192.168.1.100, user: admin

### TTS

- Preferred voice: "Nova" (warm, slightly British)
- Default speaker: Kitchen HomePod
```

## Why Separate?

Skills are shared. Your setup is yours. Keeping them apart means you can update skills without losing your notes, and share skills without leaking your infrastructure.

---

## Odoo

### odoo.bemade.org (Odoo 19 Enterprise)
- **DB:** `odoo_9354ec71_80d8_4d34_9ca6_7a339acd405f`
- **User:** Scruffy Bot (`scruffy@bemade.org`, UID 9446)
- **Password:** via `pass show odoo.bemade.org/scruffy@bemade.org`
- **API Key:** via `pass show odoo.bemade.org/api/scruffy@bemade.org` (expires ~Feb 2027)
- **Auth mode:** Bearer (API key) preferred; fallback to username/password session (JSON-RPC)
- **Client:** `odoo_mcp.client.OdooClient` (from bemade-odoo-mcp uv tool)
- **Helper script:** `scripts/odoo.py` — wraps OdooClient with credential auto-load, create() workaround, and message_post helper

### staging.durpro.com (Odoo 18)
- **DB:** `odoo_91304d71_d1d2_40d9_8c6d_ae6b589970fb`
- **User:** admin (UID 2)
- **Password:** via `pass show staging.durpro.com/admin`
- **Auth mode:** Classic JSON-RPC only (/json/2/ introduced in Odoo 19)
- **Helper script:** `scripts/staging-durpro.py` — synchronous JSON-RPC helper
- **Note:** No OdooClient support; use classic JSON-RPC via urllib

### scripts/odoo.py — CLI usage

```bash
# List models (filtered)
python3 scripts/odoo.py models --filter project

# Get fields for a model
python3 scripts/odoo.py fields project.task

# Search records (JSON domain, comma-separated fields, limit)
python3 scripts/odoo.py search project.task \
  --domain '[["project_id","=",330]]' \
  --fields 'name,stage_id,user_ids' \
  --limit 20

# Read specific records by ID
python3 scripts/odoo.py read project.task 3302,3305 --fields name,stage_id
```

### scripts/odoo.py — Library usage (async)

```python
import sys, asyncio
sys.path.insert(0, '/home/openclaw/.openclaw/workspace')
from scripts.odoo import get_client, create, post_message, format_mention

async def main():
    client = get_client()
    try:
        # Search
        tasks = await client.search_read('project.task',
            domain=[['project_id', '=', 330]],
            fields=['name', 'stage_id'],
            limit=10)

        # Create (use helper — OdooClient.create() has Odoo 19 bug)
        new_id = await create(client, 'res.partner', {'name': 'Test Co'})

        # Write (update)
        await client.write('project.task', ids=[3305], vals={'description': 'Done'})

        # Unlink (delete)
        await client.unlink('res.partner', ids=[new_id])

        # Post chatter message with @mention
        marc = format_mention(12, 'Marc Durepos')
        await post_message(client, 'project.task', 3305,
            body_html=f'<p>Task done! {marc}</p>',
            mention_partner_ids=[12])
    finally:
        await client.close()

asyncio.run(main())
```

### Gotchas
  - `message_post` requires `body_is_html=True` when body contains HTML
  - `OdooClient.create()` has a bug with Odoo 19 — use `create()` from `scripts/odoo.py` instead
  - `message_post` uses `ids=[res_id]` (not a kwarg) — handled by `post_message()` helper
  - Delete is `client.unlink(model, ids=[...])` — NOT `delete_records` (that method doesn't exist)
  - Bearer auth (API key) preferred; JSON-RPC session fallback auto-handled by `get_client()`

## Browser / Playwright

Headless Chromium automation for Odoo debugging, screenshots, and JS error capture.

- **Script:** `scripts/browser.py`
- **Playwright version:** 1.58.0 (uv tool at `/home/openclaw/.local/share/uv/tools/playwright/`)
- **Browser:** Chromium headless, no-sandbox
- **Auto-login:** reads password from `pass show odoo.bemade.org/scruffy@bemade.org`
- **Screenshots dir:** `/home/openclaw/.openclaw/workspace/screenshots/`

### CLI usage

```bash
# Take a screenshot of an Odoo page
python3 scripts/browser.py screenshot --url /odoo/project
python3 scripts/browser.py screenshot --url /odoo/project/330 --out screenshots/project-330.png

# Report JS console errors and network errors
python3 scripts/browser.py errors --url /odoo/project

# Dump full page HTML (stdout or file)
python3 scripts/browser.py dump --url /odoo/project
python3 scripts/browser.py dump --url /odoo/project --out /tmp/project.html
```

### Library usage (async)

```python
import sys, asyncio
sys.path.insert(0, '/home/openclaw/.openclaw/workspace')
from scripts.browser import OdooBrowser

async def main():
    async with OdooBrowser() as b:
        await b.login()                          # auto-reads password from pass
        await b.goto("/odoo/project")
        path = await b.screenshot("project-list")  # → screenshots/project-list.png
        errors = await b.console_errors()        # list of {type, text, url}
        net_err = await b.network_errors()       # list of {url, failure, method}
        html = await b.page_source()
        await b.fill('input[name="name"]', "Test")
        await b.click('button.btn-primary')
        result = await b.evaluate("document.title")

asyncio.run(main())
```

### Notes
- On any unhandled exception, an `error-<timestamp>.png` screenshot is saved automatically
- `console_errors()` captures `error` and `warning` level console messages + page JS errors
- Use `b.clear_errors()` to reset collected errors between navigations
- `OdooBrowser(headless=False)` for visual debugging (launches visible browser)

## GitHub

- **Account:** bemade-scruffy-bot
- **Auth:** SSH key at `~/.ssh/id_ed25519` (added to account by Marc)
- **Git protocol:** SSH (`git@github.com:...`)
- **gh CLI:** SSH works for git ops; API calls need a PAT (not yet set up)

## Email

- **Account:** scruffy@bemade.org
- **Server:** mail01.durpro.com (IMAP 993, SMTP 587)
- **Password:** via `pass show mail01.durpro.com/scruffy@bemade.org`
- **Send:** `msmtp` configured at `~/.msmtprc`
- **Read:** `python3 scripts/checkmail.py` (unread by default; `--all` for everything)

### Marc's Email (marc@bemade.org)
- **Skill:** `imap-smtp-email` at `~/.agents/skills/imap-smtp-email/`
- **Server:** mail01.durpro.com (IMAP 993)
- **Credentials:** stored in skill's `.env` (already configured)
- **Usage:**
  ```bash
  cd ~/.agents/skills/imap-smtp-email
  node scripts/imap.js check --limit 10
  node scripts/imap.js search --from <sender> --limit 10
  node scripts/imap.js search --subject <text> --recent 7d
  node scripts/imap.js fetch <uid>
  node scripts/imap.js list-mailboxes
  ```
- **Note:** Only covers marc@bemade.org (mailcow). His Gmail is not accessible.

## Shared Exchange

- **`/srv/openclaw-exchange`** — Shared folder between me and Marc. Drop files here to pass things back and forth. Owned by `mdurepos`, group `openclaw-share` (I have write access).

---

Add whatever helps you do your job. This is your cheat sheet.

## Pneumac Staging

- **URL:** https://staging.pneumac.qc.ca
- **Odoo version:** 18.0+e
- **DB name:** odoo_91aea74e_be15_4e57_a7bb_c47fd9727b99 (confirmed working; moved to CNPG cluster)
- **API key (admin):** `pass show staging.pneumac.qc.ca/api/admin` (good ~1 week from 2026-03-11)
- **Auth note:** bemade-odoo-mcp uses /json/2/ (Odoo 19 only). For Odoo 18 use classic JSON-RPC:
  ```python
  uid = rpc("common", "authenticate", [DB, "admin", KEY, {}])  # interactive=False → accepts API key
  result = rpc("object", "execute_kw", [DB, uid, KEY, "model", "method", [args], {kwargs}])
  ```
- **Status:** DB unreachable — may need kubectl to verify DB exists
