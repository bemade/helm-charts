# HEARTBEAT.md

Heartbeat runs every 30 min in the main session. This is the Project Manager role.

## Checks

### 1. Odoo Notifications (for Scruffy)
Run `scripts/odoo-urgent-check.py` to find unread notifications assigned to Scruffy.
- New task assignments → spawn Junior Developer to work on them
- @mentions from Marc → read and act/respond
- Mentions from others → escalate to Marc before responding

### 1b. Odoo Discuss Messages
Run `scripts/odoo-discuss-check.py` to check Scruffy's Discuss channels for new messages.
- Direct messages from Marc → respond in Discuss or Telegram
- Messages in channels where Scruffy is mentioned → acknowledge and act if relevant
- Messages from OdooBot → filter out welcome/help messages (not actionable)
- Track seen messages in `memory/heartbeat-state.json` under `discuss_seen`
- If Marc wants to reach Scruffy via Discuss, the DM channel (channel 341) is available

### 2. Task Queue
Check `project.task` for tasks assigned to Scruffy (user_id or user_ids contains 9446).
- For each task: review the messages in the chatter and determine if we can make
  progress
- For each task for which we can make progress: spawn Junior Developer to make progress
- Update task notes with progress using HTML in a comment (not external message).

**Also check tasks assigned to Marc or Benoît Vézina:**
- If all your assigned tasks are done or stalled, look for other tasks or helpdesk
  tickets that may benefit from AI assistance
- Offer to take over via @mention in the task or message to Marc
- Wait for approval before starting work

### 3. Email Check
Run `scripts/checkmail.py` to check scruffy@bemade.org for new messages.
- Filter for Odoo-related or Bemade work emails
- Ignore spam/newsletters
- Client emails → escalate to Marc before responding

### 4. PR/MR Status
Check open PRs (GitHub) and MRs (GitLab) that Scruffy has created.
- New review comments → address or escalate
- Approved → merge if permissions allow, or notify Marc
- Failed CI → investigate and fix
- Work complete, pending review: move to Code Review.
- **CI Passed on major version branch (18.0, 19.0, etc.)** - move to Done (Production),
  notify Marc.
- **CI Passed on staging branch (18.0-staging, 19.0-staging, etc.)** - move to Pending
  Approval (Staging), notify Marc.

### 5. CI/CD Monitoring

**Branch deployment targets:**
- `18.0-staging` / `19.0-staging` → deploys to **staging**
- `18.0` / `19.0` (major version, non-staging) → deploys to **production**

## Workflow
See `TASK_WORKFLOW.md` for the full team structure and escalation rules.

## Rules
- Don't re-alert on the same thing twice (track in `memory/heartbeat-state.json`)
- Don't check between 23:00–08:00 unless something is urgent
- If nothing needs attention → HEARTBEAT_OK
- Never advance task stage past "Code Review" without Marc's approval
- Never communicate directly with clients without Marc's approval
