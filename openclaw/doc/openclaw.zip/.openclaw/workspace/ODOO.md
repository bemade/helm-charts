# ODOO.md — Instance Notes for bemade.org

Detailed reference for interacting with the Bemade Odoo instance. See `TOOLS.md` for quick usage examples.

## Instance

| Field | Value |
|-------|-------|
| URL | https://odoo.bemade.org |
| Version | Odoo 19 Enterprise |
| DB | `odoo_9354ec71_80d8_4d34_9ca6_7a339acd405f` |
| Scruffy UID | 9446 |
| Scruffy email | scruffy@bemade.org |

## Credentials

```bash
# API key (preferred — Bearer auth, expires ~Feb 2027)
pass show odoo.bemade.org/api/scruffy@bemade.org

# Password fallback (JSON-RPC session auth)
pass show odoo.bemade.org/scruffy@bemade.org
```

Auth is handled automatically by `get_client()` in `scripts/odoo.py`.

## Key People

| Name | partner_id | Email |
|------|-----------|-------|
| Marc Durepos | 12 | marc@bemade.org |
| Scruffy Bot | (check res.users id=9446) | scruffy@bemade.org |

## Mention Format

To @mention someone in a chatter message (HTML body):

```python
from scripts.odoo import format_mention

marc = format_mention(12, 'Marc Durepos')
body = f'<p>Hey {marc}, task is done.</p>'
```

Raw HTML format:
```html
<a href="/odoo/res.partner/12"
   class="o_mail_redirect"
   data-oe-id="12"
   data-oe-model="res.partner"
   target="_blank"
   contenteditable="false">@Marc Durepos</a>
```

## Task State Fields

Project tasks have two state mechanisms:

| Field | Purpose | Values |
|-------|---------|--------|
| `stage_id` | Kanban column (many2one → project.task.type) | See below |
| `state` | Detailed status within stage | See below |

### `state` selection values
| Value | Label |
|-------|-------|
| `01_in_progress` | In Progress |
| `02_changes_requested` | Changes Requested |
| `03_approved` | Approved |
| `04_waiting_normal` | Waiting |
| `1_done` | Done |
| `1_canceled` | Cancelled |

### project.task.type stages (project 330 — Odoo MCP Tool Integration)
| id | name | fold |
|----|------|------|
| 379 | New | false |
| 378 | In progress | false |
| 376 | Done | true |

To move a task: `await client.write('project.task', ids=[task_id], values={'stage_id': 376, 'state': '1_done'})`

## Models of Interest

| Model | Description |
|-------|-------------|
| `project.project` | Projects |
| `project.task` | Tasks |
| `project.task.type` | Kanban stages |
| `res.partner` | Contacts / partners |
| `res.users` | Users |
| `mail.message` | Chatter messages |
| `sale.order` | Sales orders |
| `account.move` | Invoices / journal entries |
| `product.product` | Products (variants) |
| `product.template` | Product templates |
| `stock.picking` | Transfers / shipments |
| `crm.lead` | CRM leads/opportunities |

## Gotchas & Known Bugs

### OdooClient.create() — Odoo 19 bug
`OdooClient.create()` sends `vals_list` as a dict instead of a list. Odoo 19 requires a list.
**Fix:** Use `create()` from `scripts/odoo.py` instead. It uses raw JSON-RPC with `args: [[{...vals}]]`.

### message_post
- Must set `body_is_html=True` when body contains any HTML
- Use `ids=[res_id]` (positional), NOT as a kwarg
- **Fix:** Use `post_message()` from `scripts/odoo.py` — handles all of this automatically

### OdooClient.write() signature
- Correct: `await client.write(model, ids=[...], values={...})`
- Note: keyword is `values=`, NOT `vals=`

### OdooClient.unlink() — deleting records
- `await client.unlink(model, ids=[...])`
- Returns `True` on success
- Method is `unlink`, NOT `delete_records` (that doesn't exist)

### `kanban_state` doesn't exist on project.task in Odoo 19
The field is called `state` (selection), not `kanban_state`. Values: `01_in_progress`, `1_done`, `1_canceled`, `02_changes_requested`, `03_approved`, `04_waiting_normal`.

### Many2many write commands
Use ORM tuple commands in `values` dict:
- `(4, id)` — add a link
- `(3, id)` — remove a link
- `(6, 0, [ids])` — replace all links

### doc-bearer endpoint
Technical docs available at `/doc-bearer/{model}.json` — requires "Technical Documentation" group.
Works with Bearer auth (API key).

## API Client Reference

```python
# All operations
client.search_read(model, domain=[], fields=None, limit=10, offset=0, order=None)
client.read(model, ids=[...], fields=None)
client.search(model, domain=[], limit=None, offset=0, order=None)
client.write(model, ids=[...], values={...})   # NOTE: values=, not vals=
client.unlink(model, ids=[...])                # delete records
client.fields_get(model, attributes=[...])
client.execute(model, method, ids=[...], **kwargs)

# Workarounds (scripts/odoo.py)
await create(client, model, vals_dict)         # fixed create()
await post_message(client, model, res_id, body_html, mention_partner_ids=[])
format_mention(partner_id, name)               # returns HTML anchor string
```

## Projects

| id | name |
|----|------|
| 330 | Odoo MCP Tool Integration |

(Add more as discovered)
